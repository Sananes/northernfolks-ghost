# Heimdallr v1.0

Heimdallr v1.0 - [Online Demo](http://95.85.60.167)

---

## Screenshot

![Imgur](http://i.imgur.com/OAguN0K.png)

---

## Changelog

**Minimalism v1.0 - 21/01/2014**
+ First public

---

## Copyright & License

MIT
